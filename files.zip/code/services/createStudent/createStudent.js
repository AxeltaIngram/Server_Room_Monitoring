function createStudent(req, resp) {
  
    var testParams = {
    student:{
      "student_id": "101",
      "name": "ram",
      "class": "12",
      "age": "17"
    },
  };
  req.params = testParams;
  ClearBlade.init({request:req});
  var response = {
    err:false,
    message:"",
    payload:{}
  }

  var sendResponse = function() {
    resp.success(response)
  }
   
    var callback = function (err, data) {
        if (err) {
        	response.err= true;
          response.message = data;
        } else {
        	response.payload=data;
        }
        sendResponse();
    };
    var col = ClearBlade.Collection( {collectionName: "Student" } );
    col.create(req.params.student, callback);
}

