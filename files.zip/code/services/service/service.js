
function service(req, resp) {
  // var testParams = {
  //   asset_type_id:"a9bbdef4-2e47-4b3a-9c0c-8bb062347684",
  //   pageNum:0,        
  //   pageSize:0       
  // };
   ClearBlade.init({request:req});
  var response = {
    err:false,
    message:"",
    payload:{}
  }

  var codeEngine = ClearBlade.Code()
	var serviceToCall = "practice"
	var loggingEnabled = true

  
  if (typeof req.params.pageNum =="undefined" ){
    req.params.pageNum=0;
  }
  if (typeof req.params.pageSize =="undefined" ){
    req.params.pageSize=0;
  }
 
  var sendResponse = function() {
    resp.success(response)
  }

  var callback = function (err, data) {
    // log(data);
    	var params = {
		  asset_type_id:data.DATA[0].asset_type_id
		}
	codeEngine.execute(serviceToCall, params, loggingEnabled, function(err, datanew){
		if(err){
			resp.error("Failed to complete my service: " + JSON.stringify(datanew))
		}else{
      log(JSON.parse(datanew).results);
   data.DATA[0].AssetName=JSON.parse(datanew).results.payload.DATA[0].name;
    resp.success(data);
    }
	})
          
    //if (err) {	
      //response.err= true;
      //response.message = data;
    //} else {
      //response.payload = data;
    //}
    sendResponse();
};
  var col = ClearBlade.Collection({collectionName:"Assets"});
  var query = ClearBlade.Query();
  if (typeof req.params.asset_id!="undefined" && req.params.asset_id!="" ){
    query.equalTo("item_id", req.params.asset_id);
  }
  query.setPage(req.params.pageSize, req.params.pageNum);
  col.fetch(query, callback);
}