
// TODO Create an account on twilio.com, and enter account credentials below
// ex. USER: "BC218b72987d86855a5adb921370115a20"
// ex. PASS: "4579ac6ba4fae7b452c03c64aeae40e7"
// ex. SOURCE_NUMBER: "(+1 512-713-2913)"

// const TWILIO_CONFIG = {
//     USER : "AC218b72987d86853c5adb921370115a20",
//     PASS : "4579ca6ba4fae7b232c03c64aeae40e7",
//     SOURCE_NUMBER : "(+1 512-710-2383)"
// }

// const TWILIO_CONFIG = {
//     USER : "AC86c20cc419dca6c2df5b11f9e898a856",
//     PASS : "598731126af24149e6cb7d5efc8d1b2d",
//     SOURCE_NUMBER : "(+1 647 957 8013)"
// }

