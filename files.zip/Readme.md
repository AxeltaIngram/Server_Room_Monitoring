
# ipm package: Server_Room_Monitoring

## Overview

This system will be used to monitor a variety of temperature and humidity metrics of server room

This is an ipm package, which contains one or more reusable assets within the ipm Community. The 'package.json' in this repo is a ipm spec's package.json, [here](https://docs.clearblade.com/v/3/6-ipm/spec), which is a superset of npm's package.json spec, [here](https://docs.npmjs.com/files/package.json).

[Browse ipm Packages](https://ipm.clearblade.com)

## Setup

_Add any setup instructions, such as an API Key_

## Usage

## API

